import numpy as np
import pandas as pd
from date_utils import *
from history_generator import *
import sys
import lightgbm as lgb

train = pd.read_csv('train.csv.zip', parse_dates=['DATE'])

ATM_IDs = train.ATM_ID.unique()

pred_dates  = ['2017-08-16', '2017-08-17', '2017-08-18', '2017-08-19',
               '2017-08-20', '2017-08-21', '2017-08-22', '2017-08-23',
               '2017-08-24', '2017-08-25', '2017-08-26', '2017-08-27',
               '2017-08-28', '2017-08-29', '2017-08-30', '2017-08-31',
               '2017-09-01', '2017-09-02', '2017-09-03', '2017-09-04',
               '2017-09-05', '2017-09-06', '2017-09-07', '2017-09-08',
               '2017-09-09', '2017-09-10', '2017-09-11', '2017-09-12',
               '2017-09-13', '2017-09-14', '2017-09-15', '2017-09-16',
               '2017-09-17']


rows = []
for ATM in ATM_IDs: 
    for date in pred_dates:
        rows.append([date, ATM, np.nan])
        
test = pd.DataFrame(rows, columns = ['DATE', 'ATM_ID', 'CLIENT_OUT'])     
test['DATE'] = pd.to_datetime(test['DATE'])


train = pd.concat([train, test])
train.sort_values(by=['ATM_ID', 'DATE'], inplace=True)
train.reset_index(inplace=True, drop=True)

train['day'] = train.DATE - train.DATE.min()
train['day'] = train['day'].apply(lambda x: x.days)
train['week'] = train['day'].apply(lambda x: x//7)
train['dayofweek'] = train.DATE.apply(lambda x: x.dayofweek)
train['month_from_start'] = (train.DATE.apply(lambda x: x.year)-2015)*12 + (train.DATE.apply(lambda x: x.month) - 1)

#for_valid = train[["day", "ATM_ID", "CLIENT_OUT"]].copy()                  
#train.loc[(train.day>=928) & (train.day<958), 'CLIENT_OUT'] = np.nan

print('GENERATING ATM FEATURES', file=sys.stderr)
################### GENERATE ATM FEATURES ###################################
train['atm_mean'] = train.groupby("ATM_ID").CLIENT_OUT.expanding().mean().shift().reset_index().CLIENT_OUT
train['atm_median'] = train.groupby("ATM_ID").CLIENT_OUT.expanding().median().shift().reset_index().CLIENT_OUT
train['atm_std'] = train.groupby("ATM_ID").CLIENT_OUT.expanding().std().shift().reset_index().CLIENT_OUT
train['atm_skew'] = train.groupby("ATM_ID").CLIENT_OUT.expanding().skew().shift().reset_index().CLIENT_OUT
train['atm_zeros'] = train.groupby("ATM_ID").CLIENT_OUT.expanding().apply(lambda x: (x == 0.0).sum()).shift().reset_index().CLIENT_OUT
############################################################################


print('GENERATING WEEKNDS FEATURES', file=sys.stderr)
################### WEEKNDS ########################################
weeknds = get_weeknds_set()
till_weeknd = get_days_till_weeknd(weeknds)
from_weeknd = get_days_from_weeknd(weeknds)
num_of_weeknds = get_number_of_weeknds(weeknds)
train['is_weeknd'] = train.DATE.apply(lambda x: x in weeknds)
train['days_till_weeknd'] = train.DATE.apply(lambda x: till_weeknd[x])
train['days_from_weeknd'] = train.DATE.apply(lambda x: from_weeknd[x])
train['weeknds_this_week'] = train.DATE.apply(lambda x: num_of_weeknds[x])

train['prev_week_date'] = train.DATE.shift(7)
#train.fillna(pd.to_datetime("20141228", format='%Y%m%d'), inplace=True)
train['next_week_date'] = train.DATE.shift(-7)
#train.fillna(pd.to_datetime("20170924", format='%Y%m%d'), inplace=True)

train['weeknds_prev_week'] = train.prev_week_date.apply(lambda x: num_of_weeknds[x] if x in num_of_weeknds else 2)
train['weeknds_next_week'] = train.next_week_date.apply(lambda x: num_of_weeknds[x] if x in num_of_weeknds else 2)

train.drop(['prev_week_date', 'next_week_date'], axis=1, inplace=True)
############################################################################

print('GENERATING MONTH ONE FEATURES', file=sys.stderr)
################### MONTH ########################################
train['month'] = train.DATE.apply(lambda x: x.month)
##################################################################

atm_ids = train.ATM_ID.unique()
y_pred = []
for atmIDCUR in atm_ids:
    train_atm = train[(train.ATM_ID == atmIDCUR) & (train.day>500)]
    x_train = train_atm[(train_atm.day<958)].copy()
    #x_valid = train_atm[(train_atm.day>=928) & (train_atm.day<958)].copy()
    x_test = train_atm[train_atm.day>=958].copy()
    x_train.dropna(inplace=True)

    y_train = x_train.CLIENT_OUT
    #y_valid = for_valid[(for_valid.ATM_ID == atmIDCUR) & (for_valid.day>=928) & (for_valid.day<958)].CLIENT_OUT
    x_train.drop(['DATE', "ATM_ID", "CLIENT_OUT"], inplace=True, axis=1)
   # x_valid.drop(['DATE', "ATM_ID", "CLIENT_OUT"], inplace=True, axis=1)
    
    x_test.drop(['DATE', "ATM_ID", "CLIENT_OUT"], inplace=True, axis=1)
    
    #print(y_valid)
   
    # create dataset for lightgbm
    lgb_train = lgb.Dataset(x_train, y_train)
 #   lgb_eval = lgb.Dataset(x_valid, y_valid, reference=lgb_train)

    params = {'num_leaves': 127,
              'learning_rate': 0.01,
              'reg_lambda': 0,
              'feature_fraction': 0.8,
              'boosting_type': 'gbdt',
              'verbose': 0,
              'bagging_freq': 5,
              'bagging_fraction': 0.8, 
              'objective': 'regression',
              'task': 'train',
              'reg_alpha': 0.001,
              'max_bin': 127, 
              'reg_sqrt': True,
              'metric': {'l1'}}

    gbm = lgb.train(params,
                        lgb_train,
                        num_boost_round=200)
    
    y_pred.extend(gbm.predict(x_test))

submission = pd.DataFrame(rows, columns = ['DATE', 'ATM_ID', 'CLIENT_OUT'])        
submission.CLIENT_OUT = y_pred
submission.to_csv('submission.csv', index=False)
