export PATH=/usr/conda/bin:$PATH
source activate py3
python main.py